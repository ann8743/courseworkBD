﻿public class Det
{
    public int ID { get; set; }  // Это автоинкремент
    public string Mаrka { get; set; }
    public int T1 { get; set; }
    public double de1 { get; set; }
    public double m { get; set; }
}
