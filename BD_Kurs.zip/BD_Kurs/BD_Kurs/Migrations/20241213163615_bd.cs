﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BD_Kurs.Migrations
{
    /// <inheritdoc />
    public partial class bd : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Details",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Mаrka = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    T1 = table.Column<int>(type: "int", nullable: false),
                    de1 = table.Column<double>(type: "float", nullable: false),
                    m = table.Column<double>(type: "float", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Details", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "Itogi",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DetId = table.Column<int>(type: "int", nullable: false),
                    de1 = table.Column<double>(type: "float", nullable: false),
                    m = table.Column<double>(type: "float", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Itogi", x => x.ID);
                    table.ForeignKey(
                        name: "FK_Itogi_Details_DetId",
                        column: x => x.DetId,
                        principalTable: "Details",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Sborki",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DetId = table.Column<int>(type: "int", nullable: false),
                    TypePer = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TypeOpor = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Kbe = table.Column<double>(type: "float", nullable: false),
                    HB = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    u = table.Column<double>(type: "float", nullable: false),
                    Mater = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Khb = table.Column<double>(type: "float", nullable: false),
                    Kfb = table.Column<double>(type: "float", nullable: false),
                    Y = table.Column<double>(type: "float", nullable: false),
                    x = table.Column<double>(type: "float", nullable: false),
                    Kd = table.Column<int>(type: "int", nullable: false),
                    Km = table.Column<double>(type: "float", nullable: false),
                    z = table.Column<double>(type: "float", nullable: false),
                    thiHP = table.Column<double>(type: "float", nullable: false),
                    thi = table.Column<double>(type: "float", nullable: false),
                    Khl = table.Column<double>(type: "float", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Sborki", x => x.ID);
                    table.ForeignKey(
                        name: "FK_Sborki_Details_DetId",
                        column: x => x.DetId,
                        principalTable: "Details",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Itogi_DetId",
                table: "Itogi",
                column: "DetId");

            migrationBuilder.CreateIndex(
                name: "IX_Sborki_DetId",
                table: "Sborki",
                column: "DetId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Itogi");

            migrationBuilder.DropTable(
                name: "Sborki");

            migrationBuilder.DropTable(
                name: "Details");
        }
    }
}
